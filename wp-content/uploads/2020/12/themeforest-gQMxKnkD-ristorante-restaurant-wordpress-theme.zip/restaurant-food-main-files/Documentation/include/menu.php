<!--START LEFT SIDEBAR OPEN-->
<div class="nicdark_menu">
    
    <!--<h1 class="nicdark_title_theme">Love Travel 2.0<span>Official Nicdark Documentation</span></h1>-->

    <div class="nicdark_menu_content nicdark_nicescrool">
        <a class="nicdark_cursor_none" href=""><span>01.</span> Getting Started</a>
        <ul>
            <li><a href="index.php">Introduction</a></li>
            <li><a href="install-theme.php">Install Theme</a></li>
        </ul>
        <a class="nicdark_cursor_none" href=""><span>02.</span> Header</a>
        <ul>
            <li><a href="menu-settings.php">Menu Settings</a></li>
            <li><a href="header-settings.php">Header Settings</a></li>
            <li><a href="fav-icons.php">Favicons</a></li>
        </ul>
        <a class="nicdark_cursor_none" href=""><span>03.</span> Footer</a>
        <ul>
            <li><a href="copyright-settings.php">Copyright Settings</a></li>
        </ul>
        <a class="" href="page.php"><span>04.</span> Page</a>
        <a class="" href="post.php"><span>05.</span> Post</a>
        <a class="" href="locations.php"><span>06.</span> Locations</a>
        </ul>
        <a class="nicdark_cursor_none" href=""><span>07.</span> Shortcode</a>
        <ul>
            <li><a href="gmaps-markers.php">Gmaps Markers</a></li>
        </ul>
    </div>
        
</div>
<!--END RIGHT SIDEBAR OPEN-->